# get_text_from_img
python_图形文字提取系统

安装python-3.6.5  安装教程https://baijiahao.baidu.com/s?id=1606573927720991570
安装需要的库
pip install opencv-python -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install threading -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install multiprocessing -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install QCandyUi -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install tensorflow -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install pyqt5 -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install baidu-aip

运行程序：python main.py


